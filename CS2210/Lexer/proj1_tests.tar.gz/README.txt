The *.out files were generated using the following commands.

$ cat ./strings.mjava | ./lexer > ./strings.mjava.out
$ cat ./test.mjava | ./lexer > ./test.mjava.out
$ cat ./test2.mjava | ./lexer > ./test2.mjava.out

The output of your lexer should match these outputs save for minor
differences.
